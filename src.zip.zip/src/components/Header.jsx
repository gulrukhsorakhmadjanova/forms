function Header() {
  const { theme, setTheme } = useTheme();
  const { authUser, setAuthUser } = useAuth();
  const location = useLocation();

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light");
  };

  const handleLogout = async () => {
    // Replace with real Appwrite logout if needed
    setAuthUser(null);
    window.location.href = "/";
  };

  return (
    <header className="header">
      <div className="header-left">
        <Link to="/" className="logo">FormBuilder</Link>
        <Link to="/" className={location.pathname === "/" ? "active" : ""}>Home</Link>
        <Link to="/dashboard" className={location.pathname === "/dashboard" ? "active" : ""}>Dashboard</Link>
        <Link to="/template/create" className={location.pathname === "/template/create" ? "active" : ""}>Create</Link>
        {authUser?.isAdmin && (
          <Link to="/admin" className={location.pathname === "/admin" ? "active" : ""}>Admin Panel</Link>
        )}
      </div>

      <div className="header-right">
        <button onClick={toggleTheme} title={theme === "light" ? "Dark Mode" : "Light Mode"}>
          {theme === "light" ? "🌙" : "☀️"}
        </button>

        {authUser ? (
          <>
            <span style={{ fontWeight: "500" }}>{authUser.name}</span>
            <button onClick={handleLogout} style={{ color: "#dc2626" }}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/login" className={location.pathname === "/login" ? "active" : ""}>Login</Link>
            <Link to="/register" className={location.pathname === "/register" ? "active" : ""}>Register</Link>
          </>
        )}
      </div>
    </header>
  );
}
