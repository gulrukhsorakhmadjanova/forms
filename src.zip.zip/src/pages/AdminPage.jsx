import React, { useEffect, useState } from "react";
import { databases } from "../lib/appwrite"; 
import { useAuth } from "../App"; 
import { ID } from "appwrite";

function AdminPage() {
  const { authUser } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  const dbId = import.meta.env.VITE_APPWRITE_DB_ID;
  const usersCol = import.meta.env.VITE_APPWRITE_USERS_COLLECTION_ID;

  useEffect(() => {
    async function fetchUsers() {
      try {
        const res = await databases.listDocuments(dbId, usersCol, []);
        setUsers(res.documents);
      } catch (err) {
        console.error("Failed to fetch users:", err);
      } finally {
        setLoading(false);
      }
    }

    fetchUsers();
  }, []);

  return (
    <div className="p-6 max-w-4xl mx-auto mt-8 bg-white dark:bg-[#23232a] rounded-xl shadow-lg transition-colors duration-300">
      <h1 className="text-2xl font-bold mb-6 text-gray-900 dark:text-gray-100">👨‍💼 Admin Panel</h1>
      {loading ? (
        <p className="text-gray-600 dark:text-gray-300">Loading users...</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full border-collapse bg-white dark:bg-[#18181b] rounded-lg shadow border border-gray-200 dark:border-gray-700 transition-colors duration-300">
            <thead>
              <tr className="bg-gray-100 dark:bg-[#23232a]">
                <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Name</th>
                <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Email</th>
                <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">isAdmin</th>
                <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">isApproved</th>
                <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">isBlocked</th>
                <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Language</th>
                <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Theme</th>
                <th className="px-4 py-2 text-left text-gray-700 dark:text-gray-200">Action</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.$id} className="border-t border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-[#23232a] transition-colors">
                  <td className="px-4 py-2 text-gray-900 dark:text-gray-100">{u.name}</td>
                  <td className="px-4 py-2 text-gray-900 dark:text-gray-100">{u.email}</td>
                  <td className="px-4 py-2">{u.isAdmin ? "✅" : "❌"}</td>
                  <td className="px-4 py-2">{u.isApproved ? "✅" : "❌"}</td>
                  <td className="px-4 py-2">{u.isBlocked ? "🚫" : "✅"}</td>
                  <td className="px-4 py-2 text-gray-700 dark:text-gray-300">{u.language || "—"}</td>
                  <td className="px-4 py-2 text-gray-700 dark:text-gray-300">{u.theme || "—"}</td>
                  <td className="px-4 py-2"></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default AdminPage;
