import React, { useEffect, useState } from "react";
import { account, databases } from "../lib/appwrite";
import { useNavigate } from "react-router-dom";

const DB_ID = import.meta.env.VITE_APPWRITE_DB_ID;
const TEMPLATES_COLLECTION_ID = import.meta.env.VITE_APPWRITE_TEMPLATES_COLLECTION_ID;

function TemplateList() {
  const [templates, setTemplates] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchTemplates = async () => {
      setLoading(true);
      try {
        const res = await databases.listDocuments(DB_ID, TEMPLATES_COLLECTION_ID);
        setTemplates(res.documents);
      } catch (err) {
        setTemplates([]);
      } finally {
        setLoading(false);
      }
    };
    fetchTemplates();
  }, []);

  const filteredTemplates = templates.filter((t) =>
    t.title?.toLowerCase().includes(search.toLowerCase()) ||
    (t.tags && t.tags.some((tag) => tag.toLowerCase().includes(search.toLowerCase())))
  );

  return (
    <div className="card max-w-2xl mx-auto mt-8 bg-white dark:bg-[#23232a] rounded-xl shadow-lg transition-colors duration-300">
      <h2 className="mb-4 text-xl font-bold text-gray-900 dark:text-gray-100">All Templates</h2>
      <input
        type="text"
        placeholder="Search by title or tag..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="mb-4 w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-[#18181b] text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
      {loading ? (
        <p className="text-gray-600 dark:text-gray-300">Loading templates...</p>
      ) : filteredTemplates.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-400">No templates found.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full border-collapse bg-white dark:bg-[#18181b] rounded shadow border border-gray-200 dark:border-gray-700 transition-colors duration-300">
            <thead>
              <tr className="bg-gray-100 dark:bg-[#23232a]">
                <th className="text-left p-2 font-medium text-gray-700 dark:text-gray-200">Title</th>
                <th className="text-left p-2 font-medium text-gray-700 dark:text-gray-200">Topic</th>
                <th className="text-left p-2 font-medium text-gray-700 dark:text-gray-200">Tags</th>
                <th className="p-2 text-left font-medium text-gray-700 dark:text-gray-200"></th>
              </tr>
            </thead>
            <tbody>
              {filteredTemplates.map((t) => (
                <tr key={t.$id} className="border-t border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-[#23232a] transition-colors">
                  <td className="p-2 text-gray-900 dark:text-gray-100">{t.title}</td>
                  <td className="p-2 text-gray-900 dark:text-gray-100">{t.topic}</td>
                  <td className="p-2 text-gray-700 dark:text-gray-300">{(t.tags || []).join(", ")}</td>
                  <td className="p-2">
                    <button onClick={() => navigate(`/template/${t.$id}`)} className="text-blue-600 dark:text-blue-400 font-medium bg-none border-none cursor-pointer">Details</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await account.get();
        setUser(currentUser);
      } catch {
        navigate("/");
      }
    };
    fetchUser();
  }, []);

  const handleLogout = async () => {
    await account.deleteSession("current");
    navigate("/");
  };

  return (
    <div className="min-h-screen flex flex-col items-center bg-[#fafafb] dark:bg-[#18181b] transition-colors duration-300">
      <div className="card max-w-md w-full mt-12 bg-white dark:bg-[#23232a] rounded-xl shadow-lg transition-colors duration-300">
        <h2 className="text-center mb-2 text-xl font-bold text-gray-900 dark:text-gray-100">Dashboard</h2>
        {user ? (
          <div className="text-center">
            <p className="font-semibold text-lg text-gray-900 dark:text-gray-100">Welcome, {user.name}</p>
            <p className="text-gray-500 dark:text-gray-300 mb-4">{user.email}</p>
            <button onClick={handleLogout} className="bg-none text-blue-600 dark:text-blue-400 border-none font-medium cursor-pointer mb-4">Logout</button>
            <hr className="my-6 border-gray-200 dark:border-gray-700" />
            <h3 className="text-lg font-semibold mb-2 text-gray-900 dark:text-gray-100">Your Filled Forms</h3>
            <div className="mb-4">
              <p className="text-gray-400">No forms filled yet.</p>
              <button onClick={() => navigate("/form/create")}
                className="bg-none text-blue-600 dark:text-blue-400 border-none font-medium cursor-pointer">
                Fill New Form
              </button>
            </div>
          </div>
        ) : (
          <p className="text-gray-600 dark:text-gray-300">Loading user...</p>
        )}
      </div>
      <TemplateList />
    </div>
  );
}
