import React from "react";

export default function FormViewPage() {
  return (
    <div className="card max-w-2xl mx-auto mt-8 bg-white dark:bg-[#23232a] rounded-xl shadow-lg transition-colors duration-300">
      <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-gray-100">Form Details</h2>
      {/* TODO: Show form answers and metadata */}
      <p className="text-gray-700 dark:text-gray-300">Form details coming soon...</p>
    </div>
  );
} 