import React from "react";

export default function SearchPage() {
  return (
    <div className="card max-w-2xl mx-auto mt-8 bg-white dark:bg-[#23232a] rounded-xl shadow-lg transition-colors duration-300">
      <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-gray-100">Search Templates</h2>
      {/* TODO: Search bar and results */}
      <p className="text-gray-700 dark:text-gray-300">Search coming soon...</p>
    </div>
  );
} 