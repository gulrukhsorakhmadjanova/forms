import React, { useState } from "react";

export default function UserProfilePage() {
  const [tab, setTab] = useState("templates");
  return (
    <div className="card max-w-3xl mx-auto mt-8 bg-white dark:bg-[#23232a] rounded-xl shadow-lg transition-colors duration-300">
      <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-gray-100">My Profile</h2>
      <div className="flex gap-6 mb-6">
        <button onClick={() => setTab("templates")} className={`px-4 py-2 rounded font-semibold transition-colors ${tab === "templates" ? "bg-blue-600 text-white" : "bg-gray-100 dark:bg-[#18181b] text-gray-900 dark:text-gray-100"}`}>My Templates</button>
        <button onClick={() => setTab("forms")} className={`px-4 py-2 rounded font-semibold transition-colors ${tab === "forms" ? "bg-blue-600 text-white" : "bg-gray-100 dark:bg-[#18181b] text-gray-900 dark:text-gray-100"}`}>My Forms</button>
      </div>
      {tab === "templates" ? (
        <div className="text-gray-700 dark:text-gray-300">{/* TODO: Sortable table of user's templates */}<p>Templates table coming soon...</p></div>
      ) : (
        <div className="text-gray-700 dark:text-gray-300">{/* TODO: Sortable table of user's filled forms */}<p>Forms table coming soon...</p></div>
      )}
    </div>
  );
} 